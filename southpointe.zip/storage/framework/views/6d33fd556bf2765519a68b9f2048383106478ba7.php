  

  <?php $__env->startSection('lang'); ?><?php echo e($lang); ?><?php $__env->stopSection(); ?>

  

  <?php $__env->startSection('title'); ?><?php echo e($title); ?><?php $__env->stopSection(); ?>

  

  <?php $__env->startSection('Content-Type','text/html; charset=UTF-8'); ?>
  <?php $__env->startSection('x-ua-compatible','ie=edge'); ?>
  <?php $__env->startSection('keywords',''); ?>
  <?php $__env->startSection('description',''); ?>
  <?php $__env->startSection('facebookUrl',''); ?>
  <?php $__env->startSection('facebookImage',''); ?>
  <?php $__env->startSection('viewport','width=device-width, minimum-scale=1.0, maximum-scale=1.0, initial-scale=1'); ?>
  <?php $__env->startSection('idiomaLang','es-mx'); ?>
  <?php $__env->startSection('urlLang','http://southpointecapital.com/'); ?>

  <!--Menu Transparente-->
  <?php $__env->startSection('menuCSS','css/menu/menu.css?v='.cache("js_version_number").''); ?>

  

  <?php $__env->startSection('controller','index'); ?>

  

  <?php $__env->startSection('content'); ?>

  <!--================Home Banner Area =================-->
  <section>

  <div class="slider stick-dots">

    <div class="slide">
      <div class="slide__img">
        <img src="" alt="" data-lazy="images/mountains.jpg" class="full-image animated" data-animation-in="zoomInImage"/>
      </div>
      <div style="background: rgba(255,255,255,.6); width: 100%; height: 700px;" class="slide__content center">
        <div class="slide__content--headings center">
          <h2 style="color: black; margin-top: 250px;" class="animated center" data-animation-in="fadeInUp">COOMING SOON</h2>
          
        </div>
      </div>
    </div>

  </div>

</section>
  <!--================End Home Banner Area =================-->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>