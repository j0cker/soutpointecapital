@include('layouts.index.header')
@include('layouts.index.menu')
  @yield('content')
@include('layouts.index.footer')
